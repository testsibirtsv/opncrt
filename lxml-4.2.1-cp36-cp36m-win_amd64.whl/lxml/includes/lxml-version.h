#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "4.2.1"
#endif
